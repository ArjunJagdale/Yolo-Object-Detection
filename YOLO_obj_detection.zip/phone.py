import cv2
from ultralytics import YOLO
import pygame
import math
from twilio.rest import Client

# Initialize pygame
pygame.init()

# Load sound
sound_path = "censor-beep-9.wav"  # Change this to the path of your desired sound file
pygame.mixer.music.load(sound_path)

# Start webcam
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# Load YOLO model
model = YOLO("yolo-Weights/yolov8n.pt")

# Twilio credentials
account_sid = 'AC3ea89b91557569a43bf3a2c00337cd55'
auth_token = 'ac6137f5522854ef86f6c01f1ae0708d'
client = Client(account_sid, auth_token)

# Phone number to send SMS
to_phone_number = '+919822477044'

while True:
    success, img = cap.read()
    results = model(img, stream=True)

    # Flag to check if a cell phone is detected
    is_cellphone_detected = False

    # Coordinates
    for r in results:
        boxes = r.boxes
        for box in boxes:
            # Class name
            cls = int(box.cls[0])
            class_name = model.names[cls]

            # If a cell phone is detected, set the flag to True
            if class_name == "cell phone":
                is_cellphone_detected = True

            # Bounding box
            x1, y1, x2, y2 = box.xyxy[0]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)  # Convert to int values

            # Draw bounding box
            cv2.rectangle(img, (x1, y1), (x2, y2), (255, 0, 255), 3)

    # If a cell phone is detected, play the sound and send SMS
    if is_cellphone_detected:
        pygame.mixer.music.play()
        message = client.messages.create(
            body="Cell phone detected!",
            from_="+12057935647",
            to=to_phone_number
        )

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
