import cv2
from ultralytics import YOLO
import pygame

# Initialize pygame for sound alerts
pygame.init()

# Load sound for alerts
sound_path = "beep.wav"  # Path to sound file
pygame.mixer.music.load(sound_path)

# Initialize YOLO model
model = YOLO("yolo-Weights/yolov8n.pt")

# Function to play sound alert
def play_alert_sound():
    pygame.mixer.music.play()

# Open the video stream from the CCTV camera
# Replace the URL with the actual URL of your CCTV camera stream
video_stream = cv2.VideoCapture("rtsp://username:password@your_camera_ip:port/stream")

# Check if the video stream is opened successfully
if not video_stream.isOpened():
    print("Error: Failed to open video stream.")
    exit()

# Loop to continuously read frames from the video stream
while True:
    # Read a frame from the video stream
    ret, frame = video_stream.read()

    # Check if the frame is read successfully
    if not ret:
        print("Error: Failed to read frame from video stream.")
        break

    # Perform object detection on the frame
    results = model(frame)

    # Loop through the detected objects
    for result in results.xyxy[0]:
        # Get the class label and confidence score
        class_label = result[5]
        confidence = result[4]

        # Check if the detected object is a person (class label 0) and confidence score is high enough
        if class_label == 0 and confidence > 0.5:
            # Play alert sound
            play_alert_sound()

            # Draw a bounding box around the detected person
            x1, y1, x2, y2 = int(result[0]), int(result[1]), int(result[2]), int(result[3])
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # Display the frame with object detection overlays
    cv2.imshow("CCTV Monitoring", frame)

    # Check for key press to exit
    if cv2.waitKey(1) == ord('q'):
        break

# Release resources
video_stream.release()
cv2.destroyAllWindows()

#We open a video stream from the CCTV camera using the cv2.VideoCapture() function. You need to #replace the URL "rtsp://username:password@your_camera_ip:port/stream" with the actual URL of your #CCTV camera stream. This URL typically follows the RTSP or HTTP protocol.

#We continuously read frames from the video stream in a loop using the read() method of the #video_stream object.

#We perform object detection on each frame using the YOLO model.

#We loop through the detected objects and check if any person is detected with a confidence score #higher than a threshold (e.g., 0.5). If so, we play the alert sound and draw a bounding box around #the detected person on the frame.

#We display the frame with object detection overlays on the screen using the cv2.imshow() function.

#We check for a key press (in this case, the 'q' key) to exit the program.